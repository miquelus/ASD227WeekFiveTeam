//
//  main.m
//  Ch2Ex9
//
//  Created by user168232 on 1/7/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int GMT_time = 10, CST_time = 10;
        
        int *state1 = &CST_time;
        CST_time += 5;
        NSLog(@"\nWhen the GTM time is %i o'clock, \n then it is %i o'clock in Minnesota", GMT_time, *state1);
        
        
    }
    return 0;
}
