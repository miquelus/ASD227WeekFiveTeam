//
//  main.m
//  ClassDemoOperators
// Compound operators examples
//  Created by user168232 on 1/7/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double num1 = 6.0, num2 = 4.0;
              
        
        //multiply and assign
        num1 *= num2;
        NSLog(@"\nThe result of num1 *= num2 %.2f\n", num1);
        // devide and assign
        num1 /= num2;
        NSLog(@"\nThe result of num1 /= num2 %.2f\n", num1);
        int num3 = 6, num4 = 4;
        //modulus and assign
        num3 %= num4;
        NSLog(@"\nThe result of num3 %%= num4 %d\n", num3);
        
        
        
    }
    return 0;
}
