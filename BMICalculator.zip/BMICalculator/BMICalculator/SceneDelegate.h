//
//  SceneDelegate.h
//  BMICalculator
//
//  Created by user168232 on 1/23/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

