//
//  ViewController.m
//  BMICalculator
//
//  Created by user168232 on 1/23/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
