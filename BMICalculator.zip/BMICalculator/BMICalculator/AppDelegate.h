//
//  AppDelegate.h
//  BMICalculator
//
//  Created by user168232 on 1/23/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (readonly, strong) NSPersistentCloudKitContainer *persistentContainer;

- (void)saveContext;


@end

