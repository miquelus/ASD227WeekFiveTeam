//
//  animalControl.h
//  HandsOnLAbCh7
//
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface animalControl : NSObject
{
    NSString *animalName;
    double polulation;
    double insecticidePower;
    double growthrate;
    
}
-(id) initAnimalControl: (NSString*) theAnimalName
: (double) thePopulation
: (double) theInsecticidePower
: (double) theGrowthPower;

@property NSString *animalName;
@property double population;
@property double insecticidePower;
@property double growthRate;

-(NSString *) description;
-(double) breed
:(double) thePopulation
:(double) theGrowthrate;
-(double) sprayInsecticide
:(double) thePolulation
:(double) theInsecticidePower;
@end

NS_ASSUME_NONNULL_END
