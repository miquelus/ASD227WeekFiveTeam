//
//  main.m
//  HandsOnLAbCh7
//
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "animalControl.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //create Termite
        animalControl *Termite = [[animalControl alloc]
                                  initAnimalControl:@"Termite" :40 :0.5:5];
        //print the Termite
        NSLog(@"\nThe first animal: %@", Termite);
        
        // create Roach 
        animalControl *Roach = [[animalControl alloc] initAnimalControl:@"Roach" :200 :2.5 :.8];
        //print the Roach
        NSLog(@"\nThe second animal: %@", Roach);

    }
    return 0;
}
