//
//  animalControl.m
//  HandsOnLAbCh7
//
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import "animalControl.h"

@implementation animalControl

@synthesize animalName, population, insecticidePower, growthRate;

-(id) initAnimalControl:(NSString *)theAnimalName
                       :(double)thePopulation
                       :(double)theInsecticidePower
                       :(double)theGrowthRate
{
    if (self == [super init])
    {
        [self setAnimalName:theAnimalName];
        [self setPopulation:thePopulation];
        [self setInsecticidePower:theInsecticidePower];
        [self setGrowthRate:theGrowthRate];
    }
    return self;
}

//description method
-(NSString *) description
{
    NSString *objectString = [NSString stringWithFormat:@"\n The animal's name is: %@\n\t with population of %.2f\n\t with insecticidePower of %.2f\n\t and growthRate of %.2f\n Population after breeding is %.2f\n\t and population after spraying insecticide is %.2f", animalName, population, insecticidePower,growthRate, [self breed:population:growthRate], [self sprayInsecticide: population: growthRate] ]; return objectString;
        
    }
    
// breed method to breed the animals
    -(double) breed
    :(double) thePopulation
    :(double) theGrowthrate
    {
        return (thePopulation*(1 + theGrowthrate));
    }
// sprayinsecticide method to contol the animal growth
-(double) sprayInsecticide
:(double) thePolulation
:(double) theInsecticidePower
{
    return (thePolulation*(1-theInsecticidePower/100));
       
}

@end
