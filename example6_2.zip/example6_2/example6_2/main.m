//
//  main.m
//  example6_2
//
//  Created by user168232 on 1/14/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSString *str = @"Hello All";
        NSString *substring;
        NSUInteger strLength;
        strLength = [str length];
        NSLog(@"\nYour string is %@ ", str);
        NSLog(@"\nThe lenght of your string is %lu", (unsigned long)strLength);
        substring = [str substringFromIndex:6];
        NSLog(@"\nThe substring is %@", substring);
        substring = [str lowercaseString];
        NSLog(@"\nYour string in lower case is %@", substring);
        
    }
    return 0;
}
