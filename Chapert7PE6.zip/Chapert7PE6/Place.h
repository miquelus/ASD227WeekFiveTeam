//
//  Place.h
//  Chapert7PE6
//
//  Created by user168232 on 1/20/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Place : NSObject

// create the properties for the place class
@property (getter=getName, setter=setName:) NSString *name;
@property (getter=getCode, setter=setCode:) int postalCode;
@property (getter=getType, setter=setType:) NSString *type;


@end
