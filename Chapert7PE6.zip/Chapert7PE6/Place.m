//
//  Place.m
//  Chapert7PE6
//
//  Created by user168232 on 1/20/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Place.h"

@implementation Place : NSObject

//sythesize the properties for the place class
@synthesize name;
@synthesize postalCode;
@synthesize type;


@end
