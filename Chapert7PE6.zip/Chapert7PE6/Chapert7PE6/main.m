//
//  main.m
//  Chapert7PE6
//
//  Created by user168232 on 1/20/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Place.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // create the place object
        Place *myObject = [[Place alloc]init];
        
        //set the value of the place object
        //set and get methods are made available by the property and the synthesize
        [myObject setName:@"Atria"];
        [myObject setCode:98765];
        [myObject setType:@"Commercial"];
        
        NSLog(@"\nThe name od the place is %@", [myObject getName]);
        NSLog(@"\nThe zip code is %i", [myObject getCode]);
        NSLog(@"\nThe name of the place is %@", [myObject getType]);

    }
    return 0;
}
