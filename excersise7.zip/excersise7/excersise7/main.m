//
//  main.m
//  excersise7
//
//  Created by user168232 on 1/13/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int a = 20;
int b = 0;
void add (void)
{
    a = 30;
    b = a + 5;
    NSLog(@"\nThe sum is %d", b);
    
}
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        add();

    }
    return 0;
}
