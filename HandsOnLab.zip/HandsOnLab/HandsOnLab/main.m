//
//  main.m
//  HandsOnLab
//
//  Created by user168232 on 1/6/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int num1Int, num2Int;
        
        NSLog(@"\nEnter the first integer: ");
        scanf("%i", & num1Int);
        NSLog(@"\nEnter the second integer: ");
        scanf("%i", & num2Int);
        NSLog (@"the sum of %i and %i equal: %i ", num1Int, num2Int, num1Int * num2Int);
        
        
        
    }
    return 0;
}
