//
//  main.m
//  ch6progexe1
//
//  Created by user168232 on 1/14/21.
//  Copyright © 2021 user168232. All rights reserved.
//
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //create a variable to store the length of the arrays
        NSUInteger IdArrayLength;
        NSUInteger MayorArrayLength;
        NSUInteger RelatedArrayLength;
        //Create ID array ussing arraWithObjects method
        NSArray *IdArray = [NSArray arrayWithObjects:@"JHGUS01", @"PHYBO02",
                                 @"GFIKH98", @"JGFTB54", @"RBWKG87", @"HGTVN77", nil];
        //Create Mayor array ussing arraWithObjects method
        NSArray *MayorArray = [NSArray arrayWithObjects:@"Undecided", @"English",
                                 @"Biochemistry", @"Chemistry", @"Economics", @"Computer Science", @"Mathematics", nil];
        //Create related array ussing arraWithObjects method
        NSArray *RelatedArray = [NSArray arrayWithObjects:@"01", @"02",
                                 @"03", @"98", @"54", @"87", @"77", nil];
        // find the length of the array and print it
        IdArrayLength= [IdArray count];
        MayorArrayLength= [MayorArray count];
        RelatedArrayLength= [RelatedArray count];
        NSLog(@"\nID array has %lu elements", (unsigned long)IdArrayLength);
        // substring ID array
        for (int i = 0; i < IdArrayLength; i++) {
            NSString *substring;
            substring = [[IdArray objectAtIndex:i] substringFromIndex:5];
            NSLog(@"\nThe substring is %@", substring);
            for (int j = 0; j < RelatedArrayLength; j++){
                if (substring == RelatedArray[j]){
                    //NSLog(@"test %@",RelatedArray[j]);
                    NSLog(@"\nStudent ID %@\t\t Mayor %@",IdArray[i], MayorArray[j]);
                }
            }
        }
    }
    return 0;
}
