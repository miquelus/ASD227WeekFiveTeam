//
//  ViewController.h
//  MultiView
//
//  Created by user168232 on 1/27/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *height;
@property (retain, nonatomic) IBOutlet UITextField *weight;
@property (retain, nonatomic) IBOutlet UISegmentedControl *measure;
@property (retain, nonatomic) IBOutlet UISwitch *male;
- (IBAction)maleSelected:(id)sender;
@property (retain, nonatomic) IBOutlet UISwitch *female;
- (IBAction)femaleSelected:(id)sender;
- (IBAction)resetBtn:(id)sender;


@end

