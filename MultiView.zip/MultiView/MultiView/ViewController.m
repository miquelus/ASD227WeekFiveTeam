//
//  ViewController.m
//  MultiView
//
//  Created by user168232 on 1/27/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController
@synthesize male;
@synthesize female;
@synthesize measure;
@synthesize height;
@synthesize weight;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (IBAction)maleSelected:(id)sender {
}
- (IBAction)femaleSelected:(id)sender {
}

- (IBAction)resetBtn:(id)sender {
}
@end
