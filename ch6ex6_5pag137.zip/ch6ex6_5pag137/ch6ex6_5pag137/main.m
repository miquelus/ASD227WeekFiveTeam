//
//  main.m
//  ch6ex6_5pag137
//
//  Created by user168232 on 1/14/21.
//  Copyright © 2021 user168232. All rights reserved.
//
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       //create a variable to store the length of the array
        NSUInteger myArrayNamesLength;
        //Create an array ussing arraWithObjects method
        NSArray *myArrayNames = [NSArray arrayWithObjects:@"Chocolate", @"Vanilla",
                                 @"Raspberry", @"Blueberry", nil];
        // find the leng of the array and print it
        myArrayNamesLength = [myArrayNames count];
        NSLog(@"\nArrayNames has %lu elements", (unsigned long)myArrayNamesLength);
        // print the contents of the array
        for (int i = 0; i < myArrayNamesLength; i++) {
            NSLog(@"\nThe element at index %i is %@", i, [myArrayNames objectAtIndex:i]);
        }
    }
    return 0;
}
