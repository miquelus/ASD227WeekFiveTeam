//
//  main.m
//  factorial
//
//  Created by user168232 on 1/13/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int num = 1;
long double product = 1;
int factorial = num;
do{
product *= num;
num--;
}
while (num > 0);
NSLog(@"%i! is: %Lf", factorial, product);    }
    return 0;
}
