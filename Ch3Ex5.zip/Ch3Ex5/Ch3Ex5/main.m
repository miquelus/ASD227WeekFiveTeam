//
//  main.m
//  Ch3Ex5
//
//  Created by user168232 on 1/7/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
         char answer;
               NSLog(@"\nEnter M if your gender is Male, or F for Female");
                scanf("%s", &answer);
                    if (answer == 'M' || answer == 'm') {
                         NSLog(@"\nIt's a Boy");
                    }
                    else if(answer == 'F' || answer == 'f') {
                         NSLog(@"\nIt's a Girl");
                    }else
                        NSLog(@"\nNot a valid entry");
                        
    }
    return 0;
}
