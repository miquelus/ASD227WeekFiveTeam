//
//  main.m
//  addTwoNumbers
//
//  Created by user168232 on 1/6/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int x, y;
        x = 10;
        y = 12;
        NSLog(@"The sum of x and y is: %i", x+y);
    }
    return 0;
}
