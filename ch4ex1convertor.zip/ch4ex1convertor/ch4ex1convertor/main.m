//
//  main.m
//  ch4ex1convertor
//
//  Created by user168232 on 1/14/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        bool flag =1;
        
        while(flag != 0)
        {
        int fah = 0;
        int cent =0;
        NSLog(@"\nEnter the temperature in Fahrenheit, or press -999 to exit");
        scanf("%i", &fah);
        if (fah != -999)
        {
            cent = .5556 * (fah - 32);
            NSLog(@"\n%i Fahrenheit are %i Celcus",fah, cent);
        }
        else { flag = 0;}
        }
    }
    return 0;
}
