//
//  main.m
//  ch4ProgramExcercise3
//
//  Created by user168232 on 1/14/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int num = 0; // variable to store the number entered
        for (int i = 0; i < 5; i++){ // loop for five iterations
            NSLog(@"\nEnter a number: ");
            scanf("%d", &num); // store the number entered in a variable
            
            if (num%2 == 0){
                NSLog(@"%d is even", num);
            }
            else{
                NSLog(@"%d is odd", num);
                }
            char answer;
            NSLog(@"\nPress 'Q' to quite, or any key to continue");
            scanf(" %s", &answer);
            while((answer != 'Q') || (answer != 'q'))
                break;
        }
    }
    return 0;
}
