//
//  main.m
//  test2cases
//
//  Created by user168232 on 1/15/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        //create a variable to store the length of the arrays
        NSUInteger IdArrayLength;
        //Create ID array ussing arraWithObjects method
        NSArray *IdArray = [NSArray arrayWithObjects:@"JHGUS01", @"PHYBO02",
                                 @"GFIKH98", @"JGFTB54", @"RBWKG87", @"HGTVN77", nil];
        // find the length of the array and print it
        IdArrayLength= [IdArray count];
        NSLog(@"\nID array has %lu elements", (unsigned long)IdArrayLength);
        // substring ID array
        for (int i = 0; i < IdArrayLength; i++) {
            NSString *substring;
            substring = [[IdArray objectAtIndex:i] substringFromIndex:5];
            NSLog(@"\nThe substring is %@", substring);
            switch (substring) {
                case 01:
                    <#statements#>
                    break;
                    
                default:
                    break;
            }
            
            
            
            
                
            }
    }
    return 0;
}
