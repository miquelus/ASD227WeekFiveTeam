//
//  animalControl.h
//  chapter7demo
//
//  Created by user168232 on 1/20/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface animalControl : NSObject

@end

NS_ASSUME_NONNULL_END
