//
//  Dog.h
//  chapter7demo
//
//  Created by user168232 on 1/20/21.
//
#import <Foundation/Foundation.h>
@interface Dog : NSObject
{
    NSString *breed;
    double height;
    NSString *color;
    double weight;
}
-(void) bark;
-(void) wagTail;
-(void) shine;

@end
