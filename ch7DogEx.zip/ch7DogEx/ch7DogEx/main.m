//
//  main.m
//  ch7DogEx
//
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dog.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // create a yorkie object of the dog class
        Dog *yorkie = [[Dog alloc] init];
        
        //run the bark method
        [yorkie bark];
        
        //run the whine method
        [yorkie whine];
        
        //run the wag tail method
        [yorkie wagTail];

    }
    return 0;
}
