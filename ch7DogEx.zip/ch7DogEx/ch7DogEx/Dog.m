//
//  Dog.m
//  ch7DogEx
//
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import "Dog.h"

@implementation Dog
-(void) bark
{
    NSLog(@"\nBow Wow ... Bow Wow");
}
-(void) wagTail
{
    NSLog(@"\nI like you");
}
-(void) whine
{
    NSLog(@"\nEeeeen...Eeeeen");
}

@end
