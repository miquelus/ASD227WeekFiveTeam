//
//  Dog.h
//  ch7DogEx
// Example 7-1
//  Created by user168232 on 1/21/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Dog : NSObject
{
    NSString *breed;
    double height;
    NSString *color;
    double weight;
}
-(void) bark;
-(void) wagTail;
-(void) whine;

@end

NS_ASSUME_NONNULL_END
