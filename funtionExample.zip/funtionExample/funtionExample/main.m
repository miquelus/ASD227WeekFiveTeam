//
//  main.m
//  funtionExample
//
//  Created by user168232 on 1/13/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>
void welcome(void)
{
    NSLog(@"\nGood Evening, how are you doing tonight?");
    
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        welcome();

    }
    return 0;
}
