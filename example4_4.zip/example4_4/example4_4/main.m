//
//  main.m
//  example4_4 factorial numbers
//
//  Created by user168232 on 1/13/21.
//  Copyright © 2021 user168232. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int i = 5;
        int counter =1;
       do

{

   NSLog(@"The value of i is: %i",i);

}

while (counter < 10);
    }
    return 0;
}
